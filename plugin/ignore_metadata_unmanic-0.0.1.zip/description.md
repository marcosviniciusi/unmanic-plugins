This plugin ignores files that have already been processed by checking for a specific metadata tag.

If a file contains the configured metadata key with the expected value, it will be skipped and not added to the processing queue.

This prevents files from being unnecessarily reprocessed after they have already been handled by Unmanic.